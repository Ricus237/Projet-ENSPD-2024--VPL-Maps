package com.aaddev.my_loc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
