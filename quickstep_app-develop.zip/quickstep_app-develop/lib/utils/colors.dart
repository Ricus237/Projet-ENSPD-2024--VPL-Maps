import 'package:flutter/material.dart';

const primary = Color(0xFF4c6ebb);
const lightPrimary = Color(0xFF9fcdf5);
const white = Colors.white;
const veryLightGrey = Color(0xFFF2F2F3);
Color grey400 = Colors.grey.shade400;
const red = Colors.red;
const transparent = Colors.transparent;
