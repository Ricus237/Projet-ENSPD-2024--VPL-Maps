package com.example.quickstep_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
