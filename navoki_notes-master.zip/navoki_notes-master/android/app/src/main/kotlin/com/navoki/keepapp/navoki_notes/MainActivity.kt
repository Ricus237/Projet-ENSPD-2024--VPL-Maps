package com.navoki.keepapp.navoki_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
